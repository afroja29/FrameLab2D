#!/bin/bash
set -e
cd "$(dirname "$0")"
if command -v python3.12 >/dev/null 2>&1; then
    framelab_python=python3.12
elif command -v python3 >/dev/null 2>&1; then
    framelab_python=python3
else
    echo 'Install 64-bit Python 3.12, then open this launcher again.'
    read -r -p 'Press Enter to close.'
    exit 1
fi
if ! "$framelab_python" -c 'import sys; assert sys.version_info >= (3,10)' ; then
    echo 'This app needs Python 3.10 or newer. Python 3.12 is recommended.'
    read -r -p 'Press Enter to close.'
    exit 1
fi
"$framelab_python" -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
exec .venv/bin/python -m streamlit run streamlit_app.py
