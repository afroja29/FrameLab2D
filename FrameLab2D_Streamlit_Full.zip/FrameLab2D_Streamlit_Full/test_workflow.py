import os,sys,json,time,importlib.util,itertools
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().with_name('streamlit_app.py')
spec=importlib.util.spec_from_file_location('full_app',P);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
c={**a.DEFAULT,'active_state':'Healthy RC','ei_factor':1.}
h=a.make_model(c);rows=[dict(Element=x['Element'],Type=x['Type'],Story=x['Story'],Exposure='Combined',Ec_loss_pct=10.,As_loss_pct=10.)for x in h['audit']];c['member_losses']=rows
sensors=[dict(Node=6,Direction='X displacement',Noise_percent=0.),dict(Node=9,Direction='X displacement',Noise_percent=0.)]
t=time.perf_counter();r=a.run(c)
assert r['active']['all_checks_pass']and r['healthy']['all_checks_pass']
assert abs(r['active']['roof_static_mm']-8.646462935648273)<1e-7
assert abs(r['active']['buckling']['factors'][0]-50.832)<.001
sim=a.simulate_measurements(h,sensors,1,.3,0.,7405);diag=a.diagnose_model(h,sensors,sim)
assert diag['candidates'][0]['Element']==1 and diag['candidates'][0]['Alpha']==.3
assert diag['candidates'][0]['RMSE_raw']<1e-12
rep=a.sensitivity_report(h,sensors);assert rep['rank']==2 and rep['unresolved']==8
opt=a.optimize_sensors(c,sensors,2,.0001,.3,'Diagnosis scenarios',diag)
assert opt['active']['nodes']==[7,4],opt
cmp=a.optimize_sensors(c,sensors,2,.0001,.3,'Healthy vs deteriorated RC')
assert cmp['healthy']['dofs']==cmp['active']['dofs']and abs(cmp['old_on_active']-cmp['active']['final_score'])<1e-12
cd={**c,'active_state':'Deteriorated RC'};md=a.make_model(cd);rd=a.run(cd)
assert rd['active']['all_checks_pass']and abs(rd['active']['dynamic']['roof_peak_mm']-28.497863723718)<1e-7
cmpd=a.optimize_sensors(cd,sensors,2,.0001,.3,'Healthy vs deteriorated RC')
assert not(set(cmpd['active']['dofs'])&set(a.sensor_dofs(sensors)))
assert cmpd['active']['scores'][1]>=cmpd['active']['scores'][0]-1e-12
# Independent brute force over this 4-channel candidate pool checks reported greedy score.
pred=np.array(cmpd['predictions']);pool=[9,12,18,21];existing=[15,24]
optimum=max(a.layout_score(pred,existing+list(pair),.0001)for pair in itertools.combinations(pool,2))
assert cmpd['active']['final_score']<=optimum+1e-12
zero={**cd,'member_losses':[{**x,'Ec_loss_pct':0.,'As_loss_pct':0.}for x in rows]}
assert np.allclose(a.ref_linear(a.make_model(zero))['u'],a.ref_linear(h)['u'],atol=1e-15)
partial={**cd,'member_losses':[{**x,'Ec_loss_pct':25. if i==0 else 0.,'As_loss_pct':15. if i==0 else 0.}for i,x in enumerate(rows)]}
mp=a.make_model(partial);assert mp['el'][1:]==h['el'][1:]and mp['el'][0]!=h['el'][0]
assert a.make_model(partial)['el']==mp['el'] # Repeat apply does not compound.
# Euler cantilever benchmark for reference buckling, including real OpenSees axial forces.
EI=h['el'][0][2]*h['el'][0][4];L=3.5
cant=dict(xy=np.array([[0.,0.],[0.,L]]),el=[(0,1,*h['el'][0][2:])],F=np.zeros(6),free=np.arange(3,6),roof=np.array([1]),ncols=1,stories=1)
with a.LOCK:
 try:bk=a.buckling_reference(cant,{**c,'segments':4})
 finally:a.ops.wipe()
exact=np.pi**2*EI/(4*L**2)/1e6
assert abs(bk['factors'][0]/exact-1)<.001
# Online maximum geometry with stability refinement respects resource budget.
large={**c,'stories':4,'bays':3};large.pop('member_losses');lm=a.make_model(large);assert len(lm['el'])*4<=160
report=dict(seven_modules=True,version=r['opensees_version'],healthy_roof_mm=r['active']['roof_static_mm'],deteriorated_roof_mm=rd['active']['roof_static_mm'],dynamic_peak_mm=rd['active']['dynamic']['roof_peak_mm'],pdelta_mm=rd['active']['nonlinear']['roof_mm'],critical_healthy=r['active']['buckling']['factors'][0],noiseless_diagnosis=diag['candidates'][0],sensor_rank=rep['rank'],diagnosis_placement_nodes=opt['active']['nodes'],controlled_placement=cmpd['active'],Euler_reference_relative_error=abs(bk['factors'][0]/exact-1),zero_loss_identity=True,unaffected_members_identity=True,noncompounding_application=True,seconds=time.perf_counter()-t)
Path(__file__).resolve().with_name('STREAMLIT_NUMERICAL_TESTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
