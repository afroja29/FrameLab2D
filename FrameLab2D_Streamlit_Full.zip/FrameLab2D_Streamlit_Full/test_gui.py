from pathlib import Path
import json
from streamlit.testing.v1 import AppTest
at=AppTest.from_file(str(Path(__file__).resolve().with_name('streamlit_app.py')),default_timeout=120).run()
def ok(stage):
 assert not at.exception,[(stage,str(x.message),x.stack_trace)for x in at.exception]
 assert not at.error,[(stage,x.value)for x in at.error]
ok('home');assert len(at.tabs)==7;assert at.radio(key='active_state').value=='Healthy RC'
at.button(key='run_analysis').click().run();ok('run');r=at.session_state['result'];assert abs(r['active']['roof_static_mm']-8.646462935648273)<1e-7
at.button(key='sensor_adequacy').click().run();ok('adequacy');assert at.session_state['adequacy']['data']['rank']==2
at.button(key='simulate_data').click().run();ok('simulate');assert at.session_state['measurements']
at.button(key='run_diagnosis').click().run();ok('diagnose');assert at.session_state['diagnosis']['data']['independent_relative_error']<1e-7
at.button(key='optimize_sensors').click().run();ok('placement');assert at.session_state['placement']['data']['active']['nodes']==[7,4]
# Apply exposure must recalculate active responses and invalidate measurements.
at.button(key='apply_exposure').click().run();ok('exposure apply');assert at.radio(key='active_state').value=='Deteriorated RC'
r=at.session_state['result'];assert abs(r['active']['roof_static_mm']-9.607217787713306)<1e-7
assert 'measurements'not in at.session_state and 'diagnosis'not in at.session_state
at.button(key='exposure_reopt').click().run();ok('exposure reopt');assert at.selectbox(key='optimization_mode').value=='Healthy vs deteriorated RC';p=at.session_state['placement']['data'];assert p['healthy']and p['active']
assert p['active']['final_score']>p['healthy']['final_score']
at.button(key='accept_layout').click().run();ok('accept recommended sensors');assert len(at.session_state['sensors'])==4;assert 'placement'not in at.session_state
at.selectbox(key='remove_channel').set_value(4).run();at.button(key='remove_sensor').click().run();at.selectbox(key='remove_channel').set_value(3).run();at.button(key='remove_sensor').click().run();ok('reset network')
at.button(key='load_path_button').click().run();ok('path');assert len(at.session_state['load_path']['rows'])>=13
at.checkbox(key='show_buckling').check().run();ok('buckling mode')
at.button(key='mesh_check_button').click().run();ok('mesh check');assert 0<=at.session_state['mesh_check']['difference_pct']<1.;print('Mesh difference %:',at.session_state['mesh_check']['difference_pct'])
at.button(key='restore_healthy').click().run();ok('restore');assert abs(at.session_state['result']['active']['roof_static_mm']-8.646462935648273)<1e-7
# Model edits hide numerical results and stale study results.
old=at.session_state['result']['run_id'];at.number_input(key='roof_kN').set_value(150.).run();ok('edit load');assert not len(at.metric)
at.button(key='run_analysis').click().run();ok('fresh load');assert at.session_state['result']['run_id']!=old;assert abs(at.session_state['result']['active']['roof_static_mm']/8.646462935648273-1.5)<1e-10
# Add/remove network callbacks and demo reset.
at.selectbox(key='sensor_direction').set_value('Y displacement').run();at.button(key='add_sensor').click().run();ok('add sensor');assert len(at.session_state['sensors'])==3
at.selectbox(key='remove_channel').set_value(3).run();at.button(key='remove_sensor').click().run();ok('remove sensor');assert len(at.session_state['sensors'])==2
at.button(key='load_demo').click().run();ok('demo reset');assert at.number_input(key='roof_kN').value==100 and at.radio(key='active_state').value=='Healthy RC'
at.number_input(key='stories').set_value(3).run();ok('change geometry');assert len(at.session_state['member_losses'])==15;assert [x['Node']for x in at.session_state['sensors']]==[6,12]
report={'all_seven_tabs':True,'real_analysis':True,'sensitivity_rank':True,'noise_measurement_audit':True,'diagnosis_full_scan':True,'greedy_layout':True,'exposure_applies_and_solves':True,'exposure_invalidates_inference':True,'reoptimization_is_fresh_comparison':True,'gravity_path':True,'buckling_mode':True,'mesh_convergence':True,'restore_healthy':True,'load_edit_invalidates_and_recomputes':True,'add_remove_sensor':True,'accept_recommended_sensors':True,'demo_reset':True,'geometry_reset':True}
Path(__file__).resolve().with_name('STREAMLIT_GUI_TESTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
