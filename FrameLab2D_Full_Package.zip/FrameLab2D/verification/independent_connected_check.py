import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,json,itertools
def frame(E=200e9,A=.004,I=8e-5,n=1):
 xy=np.array([(c*6,f*3.5)for f in range(3)for c in range(3)],float);el=[]
 for f in range(1,3):
  el.extend([(3*(f-1)+c,3*f+c,E,A,I)for c in range(3)])
  el.extend([(3*f+c,3*f+c+1,E,A,I)for c in range(2)])
 if n>1:
  nodes=xy.tolist();ref=[]
  for i,j,E,A,I in el:
   ids=[i]
   for k in range(1,n):ids.append(len(nodes));nodes.append((xy[i]+k/n*(xy[j]-xy[i])).tolist())
   ids.append(j);ref.extend((ids[k],ids[k+1],E,A,I)for k in range(n))
  xy=np.array(nodes);el=ref
 F=np.zeros(3*len(xy));F[[18,21,24]]=100000/3
 return dict(xy=xy,el=el,F=F,free=np.arange(9,len(F)))
def elt(m,e):
 i,j,E,A,I=e;i=int(i);j=int(j);v=m['xy'][j]-m['xy'][i];L=np.linalg.norm(v);c,s=v/L
 a=E*A/L;b=12*E*I/L**3;cc=6*E*I/L**2;d=4*E*I/L;ee=d/2
 k=np.array([[a,0,0,-a,0,0],[0,b,cc,0,-b,cc],[0,cc,d,0,-cc,ee],[-a,0,0,a,0,0],[0,-b,-cc,0,b,-cc],[0,cc,ee,0,-cc,d]])
 T=np.array([[c,s,0,0,0,0],[-s,c,0,0,0,0],[0,0,1,0,0,0],[0,0,0,c,s,0],[0,0,0,-s,c,0],[0,0,0,0,0,1]])
 ids=np.r_[np.arange(3*i,3*i+3),np.arange(3*j,3*j+3)];return k,T,ids,L

def linear(m,alpha=None,F=None):
 if F is None:F=m['F']
 if alpha is None:alpha=np.zeros(len(m['el']))
 K=np.zeros((len(F),len(F)));data=[]
 for e,row in enumerate(m['el']):
  k,T,ids,L=elt(m,row);k=k*(1-alpha[e]);K[np.ix_(ids,ids)]+=T.T@k@T;data.append((k,T,ids,L))
 free=m['free'];u=np.zeros(len(F));u[free]=np.linalg.solve(K[np.ix_(free,free)],F[free]);forces=np.array([k@T@u[ids]for k,T,ids,L in data])
 return dict(u=u,K=K,forces=forces,R=K@u-F,data=data)

ns={'frame':frame,'linear':linear}
Ec=30e9;Es=200e9;Ab=np.pi*.016**2/4;Ib=np.pi*.016**4/64;As=4*Ab;Is=4*(Ib+Ab*.15**2);Ac=.16-As;Ic=.4**4/12-Is
EA=Ec*Ac+Es*As;EI=Ec*Ic+Es*Is
h=ns['frame'](E=Ec,A=EA/Ec,I=EI/Ec);lin=ns['linear'];existing=[15,24];pool=[9,12,18,21];sigma=.0001

def preds(m):
 ps=[lin(m)['u']]
 for e in range(10):
  a=np.zeros(10);a[e]=.3;ps.append(lin(m,a)['u'])
 return np.array(ps).T

def score(p,ds):
 if not ds:return 0
 return min(np.linalg.norm((p[ds,i]-p[ds,j])/sigma)for i in range(11)for j in range(i+1,11))
def greedy(p):
 selected=[];scores=[]
 for _ in range(2):
  best=-np.inf;chosen=None
  for d in pool:
   if d in selected:continue
   val=score(p,existing+selected+[d])
   if val>best+1e-12:best=val;chosen=d
  selected.append(chosen);scores.append(best)
 return selected,scores
pH=preds(h);dh,sh=greedy(pH);cases=[]
for name,where,ce,ar in [('zero',[],0,0),('bottom',list(range(3)),.1,.2),('left columns',[0,5],.35,.3),('all',list(range(10)),.1,.1)]:
 m=ns['frame'](E=Ec,A=EA/Ec,I=EI/Ec)
 EAd=(1-ce)*Ec*Ac+Es*(1-ar)*As;Isd=4*((1-ar)**2*Ib+(1-ar)*Ab*.15**2);EId=(1-ce)*Ec*Ic+Es*Isd
 for e in where:
  i,j,_,_,_=m['el'][e];m['el'][e]=(i,j,Ec,EAd/Ec,EId/Ec)
 p=preds(m);d,s=greedy(p)
 assert not(set(d)&set(existing)) and len(set(d))==2
 assert s[1]>=s[0]-1e-10
 optimum=max(score(p,existing+list(pair))for pair in itertools.combinations(pool,2))
 if name=='zero':assert np.array_equal(pH,p) and d==dh and s==sh
 cases.append(dict(case=name,healthy_nodes=[x//3+1 for x in dh],deteriorated_nodes=[x//3+1 for x in d],healthy_score=sh[-1],old_on_deteriorated=score(p,existing+dh),new_score=s[-1],best_of_all_pairs=optimum,roof_mm=np.mean(p[[18,21,24],0])*1000))
assert abs(cases[0]['roof_mm']-8.646462935648419)<1e-7
# Exact exported-noise identity and healthy hypothesis (no random-seed equivalence claimed).
ytrue=pH[existing,1];z=np.array([.25,-.4]);sig=np.array([1e-4,2e-4]);y=ytrue+sig*z
assert abs(np.sum(((y-ytrue)/sig)**2)-(.25**2+.4**2))<1e-12
print(json.dumps(cases,indent=2));Path(__file__).resolve().parent.mkdir(exist_ok=True)
Path(__file__).with_name('Independent_connected_checks.json').write_text(json.dumps(dict(cases=cases,matlab_runtime_executed=False,checks=['zero-loss equality','same geometry, loading and reference section','11 controlled scenarios','fixed absolute X-noise','same budget and candidate pool','no duplicate or existing-channel selection','cumulative score monotonicity','brute-force pair comparison','exact residual export identity']),indent=2))
